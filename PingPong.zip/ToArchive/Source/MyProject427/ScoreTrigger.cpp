// Fill out your copyright notice in the Description page of Project Settings.


#include "ScoreTrigger.h"
#include "Components/BoxComponent.h"

// Sets default values
AScoreTrigger::AScoreTrigger() :
	Score(0),
	bCanTrigger(true)
{
	PrimaryActorTick.bCanEverTick = true;
	CollisionBox = CreateDefaultSubobject<UBoxComponent>(TEXT("CollisionBox"));
	CollisionBox->SetCollisionResponseToAllChannels(ECollisionResponse::ECR_Block);
	CollisionBox->SetupAttachment(RootComponent);
}

// Called when the game starts or when spawned
void AScoreTrigger::BeginPlay()
{
	Super::BeginPlay();
	CollisionBox->OnComponentBeginOverlap.AddDynamic(this, &AScoreTrigger::OnBoxOverlap); 
	CollisionBox->OnComponentEndOverlap.AddDynamic(this, &AScoreTrigger::OnBoxEndOverlap);
}

// Called every frame
void AScoreTrigger::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

void AScoreTrigger::OnBoxOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComponent, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	
	if (bCanTrigger)
	{
		UE_LOG(LogTemp, Warning, TEXT("Score = %d"), Score);
		Score++;
		bCanTrigger = false;
		
	}
}

void AScoreTrigger::OnBoxEndOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)
{
	UE_LOG(LogTemp, Warning, TEXT("Overlap end"));
	GetWorld()->GetTimerManager().SetTimer(ResetScoreTriggerHandler, this, &AScoreTrigger::ResetScoreTrigger, 2.f);
}

void AScoreTrigger::ResetScoreTrigger()
{
	bCanTrigger = true;
}

