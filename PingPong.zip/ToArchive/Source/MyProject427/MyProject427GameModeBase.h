// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "MyProject427GameModeBase.generated.h"

/**
 * 
 */
UCLASS()
class MYPROJECT427_API AMyProject427GameModeBase : public AGameModeBase
{
	GENERATED_BODY()
	
};
