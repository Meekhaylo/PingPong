// Fill out your copyright notice in the Description page of Project Settings.


#include "PlatformPawn.h"
#include "PlatformPlayerController.h"


#include "Kismet/GameplayStatics.h"

void APlatformPlayerController::BeginPlay()
{
	Super::BeginPlay();
	ControlledPawn = Cast<APlatformPawn>(this->GetPawn());
}

void APlatformPlayerController::SetupInputComponent()
{
	Super::SetupInputComponent();
	InputComponent->BindAxis("MoveRight", this, &APlatformPlayerController::Move);
}

void APlatformPlayerController::Move(float Value)
{
	
	if (ControlledPawn)
	{
		ControlledPawn->Moving(Value);
	}
}

void APlatformPlayerController::SetPlayerEnabledState(bool bPlayerEnabled)
{
	if (bPlayerEnabled)
	{
		EnableInput(this);
		GetPawn()->EnableInput(this);
	}
	else
	{
		DisableInput(this);
		GetPawn()->DisableInput(this);
	}

}




/*
//Enhanced input section
void ABasePlayerController::BeginPlay()
{
	Super::BeginPlay();
	ControlledPawn = Cast<ABasePawn>(GetPawn());
	if (ULocalPlayer* LocalPlayer = Cast<ULocalPlayer>(Player))
	{
		InputSubSystem = LocalPlayer->GetSubsystem<UEnhancedInputLocalPlayerSubsystem>();
		if (InputSubSystem)
		{
			InputSubSystem->AddMappingContext(SCMapCont, 0);
		}
	}
}

void ABasePlayerController::SetupInputComponent()
{
	Super::SetupInputComponent();
	UEnhancedInputComponent* Input = Cast<UEnhancedInputComponent>(InputComponent);
	Input->BindAction(IAMoving, ETriggerEvent::Triggered, this, &ABasePlayerController::Move);
}
*/