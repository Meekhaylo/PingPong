// Fill out your copyright notice in the Description page of Project Settings.


#include "TwoPlayersGameModeBase.h"
#include "Kismet/GameplayStatics.h"




ATwoPlayersGameModeBase::ATwoPlayersGameModeBase()
{
	bPauseable = true;
	bStartPlayersAsSpectators = false;
	
	//MyDelegate.AddDynamic(this, &ATwoPlayersGameModeBase::PrintMessage);
}


void ATwoPlayersGameModeBase::PostLogin(APlayerController* NewPlayer)
{
	Super::PostLogin(NewPlayer);
	GEngine->AddOnScreenDebugMessage(1, 30.f, FColor::White, TEXT("Waiting for players"));
	//(NewPlayer);
	PlayerControllerList.Add(NewPlayer);
	if (PlayerControllerList.Num() == 2)
	{
		this->RestartPlayer(PlayerControllerList[0]);
		this->RestartPlayer(PlayerControllerList[1]);
		GEngine->AddOnScreenDebugMessage(1, 5.f, FColor::White, TEXT("Game started"));
		//bGameCanStart = true;
		
	}
}


void ATwoPlayersGameModeBase::BeginPlay()
{
	Super::BeginPlay();
	//MyDelegate.Broadcast();
	
}

/*
void ATwoPlayersGameModeBase::PrintMessage()
{
	
}

*/

