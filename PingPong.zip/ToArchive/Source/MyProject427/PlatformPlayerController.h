// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PlayerController.h"
#include "PlatformPawn.h"
#include "PlatformPlayerController.generated.h"

/**
 * 
 */
UCLASS()
class MYPROJECT427_API APlatformPlayerController : public APlayerController
{
	GENERATED_BODY()
protected:
	virtual void BeginPlay() override;

	virtual void SetupInputComponent() override;

private:
	APlatformPawn* ControlledPawn;

	UFUNCTION(BlueprintCallable)
	void Move(float Value);

	UFUNCTION(BlueprintCallable)
	void SetPlayerEnabledState(bool bPlayerEnabled);


	/*
	//Enhanced input section
	UEnhancedInputLocalPlayerSubsystem* InputSubSystem;

	UPROPERTY(EditAnywhere, Category = Input)
	UInputMappingContext* SCMapCont;

	UPROPERTY(EditAnywhere, Category = Input)
	UInputAction* IAMoving;
	*/
};
