// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "ScoreTrigger.generated.h"

UCLASS()
class MYPROJECT427_API AScoreTrigger : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AScoreTrigger();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	UFUNCTION()
	void OnBoxOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComponent, int32 OtherBodyIndex,
		bool bFromSweep, const FHitResult& SweepResult);

	UFUNCTION()
	void OnBoxEndOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "CPP_Properties", meta = (AllowPrivateAccess = "true"))
	class UBoxComponent* CollisionBox;

private:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "CPP_Properties", meta = (AllowPrivateAccess = "true"))
	int32 Score;

	bool bCanTrigger;

	FTimerHandle ResetScoreTriggerHandler;

	UFUNCTION()
	void ResetScoreTrigger();
};
