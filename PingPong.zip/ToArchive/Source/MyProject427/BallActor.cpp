// Fill out your copyright notice in the Description page of Project Settings.


#include "BallActor.h"
#include "Components/SphereComponent.h"
#include "GameFramework/ProjectileMovementComponent.h"
#include "TwoPlayersGameModeBase.h"

// Sets default values
ABallActor::ABallActor()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	SphereComp = CreateDefaultSubobject<USphereComponent>(TEXT("Sphere Collider"));
	RootComponent = SphereComp;

	BodyMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Body Mesh"));
	BodyMesh->SetupAttachment(SphereComp);

	ProjectileMovementComponent = CreateDefaultSubobject<UProjectileMovementComponent>(TEXT("Projectile movement component"));
}

// Called when the game starts or when spawned
void ABallActor::BeginPlay()
{
	Super::BeginPlay();
	ProjectileMovementComponent->UpdatedComponent = RootComponent;
	ProjectileMovementComponent->MaxSpeed = 2000.f;
	ProjectileMovementComponent->Friction = 0.f;
	ProjectileMovementComponent->ProjectileGravityScale = 0.f;
	ProjectileMovementComponent->bShouldBounce = true;
	ProjectileMovementComponent->Velocity = FVector{ 0, 0, 0 };
	ProjectileMovementComponent->SetIsReplicated(true);
}

// Called every frame
void ABallActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

void ABallActor::NotifyHit(UPrimitiveComponent* MyComp, AActor* Other, UPrimitiveComponent* OtherComp, bool bSelfMoved, FVector HitLocation, FVector HitNormal, FVector NormalImpulse, const FHitResult& Hit)
{
	Super::NotifyHit(MyComp, Other, OtherComp, bSelfMoved, HitLocation, HitNormal, NormalImpulse, Hit);
	FVector Bounce
	{
		-2 *
		FVector::DotProduct(ProjectileMovementComponent->Velocity, HitNormal) *
		HitNormal +
		ProjectileMovementComponent->Velocity
	};
	ProjectileMovementComponent->Velocity = Bounce;
}

void ABallActor::SetVelocityToPlay()
{
	this->ProjectileMovementComponent->Velocity = FVector{ 2000, 2000, 0 };
}

