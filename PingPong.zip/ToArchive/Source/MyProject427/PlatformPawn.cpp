// Fill out your copyright notice in the Description page of Project Settings.


#include "PlatformPawn.h"

#include "Components/BoxComponent.h"
#include "Camera/CameraComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "Kismet/GameplayStatics.h"

// Sets default values
APlatformPawn::APlatformPawn() :
	SpeedModifyer(1000)
{
 	// Set this pawn to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	BoxComp = CreateDefaultSubobject<UBoxComponent>(TEXT("Box Collider"));
	RootComponent = BoxComp;

	BodyMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Body Mesh"));
	BodyMesh->SetupAttachment(BoxComp);

	SpringArmComp = CreateDefaultSubobject<USpringArmComponent>(TEXT("SpringArm Component"));
	SpringArmComp->SetupAttachment(RootComponent);

	CameraComp = CreateDefaultSubobject<UCameraComponent>(TEXT("Camera Component"));
	CameraComp->SetupAttachment(SpringArmComp);

	bReplicates = true;
}

// Called when the game starts or when spawned
void APlatformPawn::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void APlatformPawn::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

// Called to bind functionality to input
void APlatformPawn::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

}

void APlatformPawn::Moving(float Value)
{
	FVector DeltaLocation{ 0, 0, 0 };
	DeltaLocation.Y = Value * SpeedModifyer * UGameplayStatics::GetWorldDeltaSeconds(this);
	AddActorLocalOffset(DeltaLocation, true);

	if (!HasAuthority())
	{
		Server_Moving(Value);
	}
}

bool APlatformPawn::Server_Moving_Validate(float Value)
{
	return true;
}

void APlatformPawn::Server_Moving_Implementation(float Value)
{
	FVector DeltaLocation{ 0, 0, 0 };
	DeltaLocation.Y = Value * SpeedModifyer * UGameplayStatics::GetWorldDeltaSeconds(this);
	AddActorLocalOffset(DeltaLocation, true);
	UE_LOG(LogTemp, Warning, TEXT("Server_Moving_Implementation Called"));
}





/*
//Enhanced input section
void APlatformPawn::Moving()
{
	const FVector2D MoveDirection = Value.Get<FVector2D>();
	if (GetController())
	{
		//UE_LOG(LogTemp, Warning, TEXT("Receiving - %f"), MoveDirection.X);
		AddMovementInput(GetActorRightVector(), MoveDirection.X * 1000);
	}
}
*/
