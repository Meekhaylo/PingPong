// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "BallActor.h"

#include "TwoPlayersGameModeBase.generated.h"


//DECLARE_DYNAMIC_MULTICAST_DELEGATE(FDel);
//DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FDel2, bool, bVarName);


UCLASS()
class MYPROJECT427_API ATwoPlayersGameModeBase : public AGameModeBase
{
	GENERATED_BODY()
public:
	//UPROPERTY()
	//FDel MyDelegate;

	//UPROPERTY()
	//FDel2 MyBoolDelegate;

	//UFUNCTION()
	//void PrintMessage();

	ATwoPlayersGameModeBase();

	virtual void PostLogin(APlayerController* NewPlayer) override;

	virtual void BeginPlay() override;


	UPROPERTY()
	TArray<APlayerController*> PlayerControllerList;

	UFUNCTION(BlueprintCallable)
	FORCEINLINE TArray<APlayerController*> GetPlayerControllerList() { return PlayerControllerList; }

	//UPROPERTY(BlueprintReadOnly)
	//bool bGameCanStart;

	//TSubclassOf<ABallActor> ABallActorClass;
	//ABallActor* ABallActorRef;
	//FORCEINLINE bool GetGameCanStart() { return bGameCanStart; }
	
};
